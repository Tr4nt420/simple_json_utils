# Json Utilities
This package has two small functions, `get_json` `save_json`,
`get_json` will require a path to a json file as it's first argument and then will return a dict object
`save_json` will require a dict object and the path to a json file
